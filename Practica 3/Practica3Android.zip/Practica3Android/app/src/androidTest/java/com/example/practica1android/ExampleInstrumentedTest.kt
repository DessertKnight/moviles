package com.example.practica1android

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.practica1android.database.Comanda
import com.example.practica1android.database.Orden
import com.example.practica1android.database.OrdenDatabaseDAO
import com.example.practica1android.database.PizzasDataBase
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.Assert.*
import org.junit.Before
import java.io.IOException

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */

@RunWith(AndroidJUnit4::class)
class PizzasDatabaseTest {
    private lateinit var ordendatabaseDao: OrdenDatabaseDAO
    private lateinit var db: PizzasDataBase

    @Before
    fun createDb() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        // Using an in-memory database because the information stored here disappears when the
        // process is killed.
        db = Room.inMemoryDatabaseBuilder(context, PizzasDataBase::class.java)
            // Allowing main thread queries, just for testing.
            .allowMainThreadQueries()
            .build()
        ordendatabaseDao = db.ordenDatabaseDao
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    @Throws(Exception::class)
    fun insertAndGetFirstOrden() {
        val comanda = Comanda()
        val orden = Orden(ordenComandaId = comanda.comandaId, platillo = "Pepperoni", cantidad = 1, precio = 100.0)
        ordendatabaseDao.insert(comanda, orden)
        val reg = ordendatabaseDao.getFirst()
        assertEquals(reg.first().platillo, "Pepperoni")
    }

    @Test
    @Throws(Exception::class)
    fun insertAndGetComandaDetalle() {
        val comanda = Comanda()
        var orden = Orden(ordenComandaId = comanda.comandaId, platillo = "Queso", cantidad = 1, precio = 100.0)
        ordendatabaseDao.insert(comanda, orden)
        orden = Orden(ordenComandaId = comanda.comandaId, platillo = "Italiana", cantidad = 1, precio = 150.0)
        ordendatabaseDao.insert(comanda, orden)
        val reg = ordendatabaseDao.getDetalleComanda(comanda.comandaId)
        assertEquals(reg.size, 2)
    }
}

/*@RunWith(AndroidJUnit4::class)
class ExampleInstrumentedTest {
    @Test
    fun useAppContext() {
        // Context of the app under test.
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.example.practica1android", appContext.packageName)
    }
}*/