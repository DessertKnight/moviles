package com.example.practica1android

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class OrdenViewModel : ViewModel(){

    private val _orden = MutableLiveData<MutableList<String>>()
    private val orden : LiveData<MutableList<String>> get() =_orden
    private val _cont = MutableLiveData<Int>()
    private val cont : LiveData<Int> get() = _cont

    init {
        _orden.value=mutableListOf<String>()
        Log.i("OrdenViewModel","Se ha creado un OrdenViewModel")
        _cont.value=0
    }

    override fun onCleared() {
        super.onCleared()
        Log.i("OrdenViewModel","Se ha destruido el objeto OrdenViewModel")
    }

    fun addOrden(string: String){
        //val item= mutableListOf<String>()
        //item.add(string)
        _orden.value?.add(string)
    }

    fun getOrden(): List<String>? {
        return orden.value
    }

    fun addCont(int: Int){
        _cont.value=int
        //_cont.value?.plus(int)
    }

    fun getCont(): Int? {
        Log.i("contadornum","total"+cont.value)
        return cont.value
    }

}