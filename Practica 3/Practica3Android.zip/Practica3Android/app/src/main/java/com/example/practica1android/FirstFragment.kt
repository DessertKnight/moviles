package com.example.practica1android

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.practica1android.databinding.FragmentFirstBinding

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    //private var orden : MutableList<String> = mutableListOf()

    private var carro = 0

    private lateinit var viewModel : OrdenViewModel

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        Log.i("FirstFragment", "Se ha llamado el ViewModelProvider.get")
        viewModel = ViewModelProvider(this).get(OrdenViewModel::class.java)
        //viewModel = ViewModelProvider(this, viewModelFactory).get(OrdenViewModel::class.java)

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tx7.text = viewModel.getCont().toString()

        binding.buttonFirst.setOnClickListener {
            nextButton()
            //findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        }
        binding.imagepizzaqueso.setOnClickListener{
            //viewModel.addOrden("Pizza Queso se agrego a la lista");
            viewModel.addOrden("Queso");
            cuentaOrdenes()
            muestraOrdenes()
            //muestraOrdenqueso()
        }
        binding.imagepizzaclasica.setOnClickListener{
            //viewModel.addOrden("Pizza Peperoni se agrego a la lista");
            viewModel.addOrden("Peperoni");
            cuentaOrdenes()
            muestraOrdenes()
            //muestraOrdenclasica()
        }
        binding.imagepizzaitaliana.setOnClickListener{
            //viewModel.addOrden("Pizza Italiana se agrego a la lista");
            viewModel.addOrden("Italiana");
            cuentaOrdenes()
            muestraOrdenes()
            //muestraOrdenitaliana()
        }
        binding.fab.setOnClickListener(){
            nextButton()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun nextButton(){
        //val action = FirstFragmentDirections.actionFirstFragmentToSecondFragment(viewModel.getOrden()!!.toTypedArray())
        //findNavController().navigate(action)
        //findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        //val action = FirstFragmentDirections.actionFirstFragmentToSecondFragment(viewModel.getOrden()!!.toTypedArray())
        //findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        val action = FirstFragmentDirections.actionFirstFragmentToSecondFragment(viewModel.getOrden()!!.toTypedArray())
        findNavController().navigate(action)
    }

    fun displayToast(message : String){
        Toast.makeText(binding.root.context, message, Toast.LENGTH_SHORT).show()
    }

    fun muestraOrdenes(){
        for(item in viewModel.getOrden()!!){
            displayToast(item)
        }
    }


    fun cuentaOrdenes(){

        carro = 0

        for(item in viewModel.getOrden()!!){
            carro += 1
            viewModel.addCont(carro)
        }
        binding.tx7.text = viewModel.getCont().toString() //carro.toString()

    }

    /*fun muestraOrdenclasica(){
        displayToast(getString(R.string.orden_clasica))
    }

    fun muestraOrdenqueso(){
        displayToast(getString(R.string.orden_queso))
    }

    fun muestraOrdenitaliana(){
        displayToast(getString(R.string.orden_italiana))
    }*/
}