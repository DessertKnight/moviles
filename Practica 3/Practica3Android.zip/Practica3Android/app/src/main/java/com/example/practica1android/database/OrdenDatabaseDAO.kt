package com.example.practica1android.database

import androidx.room.*

@Dao
interface OrdenDatabaseDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(comanda: Comanda, orden: Orden)

    @Update
    fun update(orden: Orden)

    @Query("SELECT * FROM orden ORDER BY ordenId DESC LIMIT 1")
    fun getFirst(): List<Orden>

    @Transaction
    @Query("SELECT * FROM orden WHERE ordencomandaId = :comandaId")
    fun getDetalleComanda(comandaId: Long): List<Orden>

}