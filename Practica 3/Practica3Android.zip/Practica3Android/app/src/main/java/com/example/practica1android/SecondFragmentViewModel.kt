package com.example.practica1android

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import com.example.practica1android.database.Comanda
import com.example.practica1android.database.Orden
import com.example.practica1android.database.OrdenDatabaseDAO
import com.example.practica1android.database.PizzasDataBase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SecondFragmentViewModel(ordenA: Array<String>, application: Application) : AndroidViewModel(application) {
    private lateinit var ordendatabaseDao: OrdenDatabaseDAO
    private val _orden = MutableLiveData<List<String>>()
    private val orden : LiveData<List<String>> get() = _orden
    private val ordenT = ordenA
    private lateinit var db: PizzasDataBase
    private var _orden_mutable = MutableLiveData<Orden?>()
    val orden_mutable: MutableLiveData<Orden?> get() = _orden_mutable

    fun doneNavigating() {
        _orden_mutable.value = null
    }

    init {
        _orden.value = ordenA.toList()
        Log.i("SecondFragmentViewModel", "Final array is...")
        for (i in ordenA){
            Log.i("SecondFragmentViewModel", "$ordenA")
        }
        db = Room.databaseBuilder(application, PizzasDataBase::class.java, "pizza").build()
        ordendatabaseDao = db.ordenDatabaseDao
    }
    fun getOrden(): List<String>? {
        return orden.value
    }

    fun iniDato(){
        CoroutineScope(Dispatchers.IO).launch {
            val comandaT = Comanda()
            val ordenTotal = ordenT
            var plato: String = ""
                for (x in ordenTotal){
                    plato +=" - "+x
                }
            val nuevaOrden = Orden(ordenComandaId = comandaT.comandaId, platillo = plato)
            ordendatabaseDao.insert(comandaT, nuevaOrden)
            _orden_mutable.postValue(nuevaOrden)
        }
    }



}

class SecondFragmentViewModelFactory(private val ordenA: Array<String>, private val application: Application): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(SecondFragmentViewModel::class.java)){
            return SecondFragmentViewModel(ordenA, application) as T
        }
        throw IllegalArgumentException("Unknow ViewModel class")
        }
    }
